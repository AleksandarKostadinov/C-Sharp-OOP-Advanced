﻿namespace _08.MilitaryElite.Interfaces
{
    public interface ISpecialisetSoldier : IPrivate
    {
        string Corps { get; }
    }
}
