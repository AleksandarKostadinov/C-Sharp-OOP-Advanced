﻿namespace _08.MilitaryElite.Interfaces
{
    public interface IPrivate : ISoldier
    {
        double Salary { get; }
    }
}
