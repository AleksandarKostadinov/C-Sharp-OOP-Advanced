﻿namespace _08.MilitaryElite.Interfaces
{
    public interface ISoldier
    {
        string ID { get; }

        string FirstName { get; }

        string Lastname { get; }
    }
}
